<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>OEMS - Home</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .header {
      position: absolute;
      top: 20px;
      right: 30px;
    }

    .header a {
      background: linear-gradient(to right, #4a00e0, #8e2de2);
      padding: 10px 20px;
      border-radius: 8px;
      color: #fff;
      font-weight: 600;
      text-decoration: none;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
      transition: background 0.3s ease, transform 0.2s ease;
    }

    .header a:hover {
      background: linear-gradient(to right, #8e2de2, #4a00e0);
      transform: scale(1.05);
    }

    .hero {
      text-align: center;
      margin-top: 80px;
      animation: fadeIn 1s ease;
    }

    .hero h1 {
      font-size: 48px;
      font-weight: bold;
      color: #ffffff;
      text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
    }

    .tagline {
      font-size: 18px;
      color: #ddd;
      margin-top: 10px;
    }

    .info {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 40px;
      margin-top: 60px;
      padding: 20px;
    }

    .info-block {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(12px);
      border-radius: 15px;
      padding: 30px;
      width: 300px;
      color: #fff;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      transition: transform 0.3s ease;
    }

    .info-block:hover {
      transform: translateY(-8px);
      background: rgba(255, 255, 255, 0.2);
    }

    .info-block h2 {
      font-size: 22px;
      margin-bottom: 15px;
      color: #ffdede;
    }

    .info-block p {
      font-size: 15px;
      line-height: 1.6;
      color: #f1f1f1;
    }
  </style>
</head>
<body>

  <!-- Header -->
  <header class="header">
    <a href="index.php">Login</a>
  </header>

  <!-- Hero Section -->
  <section class="hero">
    <h1>OEMS</h1>
    <p class="tagline">Your Exams, Streamlined and Simplified!</p>
  </section>

  <!-- Info Section -->
  <section class="info">
    <div class="info-block">
      <h2>OEMS</h2>
      <p>An intelligent Online Examination Management System designed to simplify the creation, delivery, and evaluation of exams for schools, colleges, and institutions.</p>
    </div>
    <div class="info-block">
      <h2>Why Choose OEMS?</h2>
      <p>OEMS enhances examination efficiency by automating the entire process. It supports real-time grading, secure student access, and user-friendly interfaces—making exam management seamless for administrators and stress-free for students.</p>
    </div>
  </section>

</body>
</html>
