<?php
session_start();
include 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "SELECT exams.title, results.score, exams.duration, results.submitted_at
          FROM results
          JOIN exams ON results.exam_id = exams.id
          WHERE results.user_id = $user_id
          ORDER BY results.submitted_at DESC";

$results = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Results</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .results-container {
            max-width: 800px;
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(12px);
            border-radius: 15px;
            padding: 30px;
            margin: 50px auto;
            animation: fadeInUp 1s ease-in-out;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
        }

        @keyframes fadeInUp {
            from {
                transform: translateY(40px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .results-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #4a00e0;
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
        }

        .results-table th,
        .results-table td {
            padding: 15px;
            text-align: left;
        }

        .results-table th {
            background-color: #4a00e0;
            color: white;
        }

        .results-table tr:nth-child(even) {
            background-color: #f3f3f9;
        }

        .results-table tr:hover {
            background-color: #eaeaff;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
        }
    </style>
</head>
<body>
    <div class="results-container">
        <h2>My Exam Results</h2>

        <?php if ($results->num_rows > 0): ?>
            <table class="results-table">
                <tr>
                    <th>Exam Title</th>
                    <th>Score</th>
                    <th>Duration (mins)</th>
                    <th>Date Taken</th>
                </tr>
                <?php while ($row = $results->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['score']; ?></td>
                        <td><?php echo $row['duration']; ?></td>
                        <td><?php echo $row['submitted_at']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p style="text-align:center;">No results found.</p>
        <?php endif; ?>

        <p class="back-link"><a href="student/dashboard.php">⬅ Back to Dashboard</a></p>
    </div>
</body>
</html>
