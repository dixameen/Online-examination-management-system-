<?php
session_start();
include 'includes/config.php';

$msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, full_name, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $name, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['full_name'] = $name;
            $_SESSION['role'] = $role;

            if ($role == 'admin') {
                header("Location: admin/dashboard.php");
            } else {
                header("Location: student/dashboard.php");
            }
            exit();
        } else {
            $msg = "Invalid password!";
        }
    } else {
        $msg = "Email not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - OEMS</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Your external glassmorphism style -->
</head>
<body>

    <div class="container">
        <h2>Login to OEMS</h2>

        <form method="POST">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required>

            <input type="submit" value="Login">
        </form>

        <?php if (!empty($msg)) : ?>
            <div class="message error"><?php echo $msg; ?></div>
        <?php endif; ?>

        <p style="margin-top: 15px;">Don't have an account? <a href="register.php">Register here</a></p>
    </div>

</body>
</html>
