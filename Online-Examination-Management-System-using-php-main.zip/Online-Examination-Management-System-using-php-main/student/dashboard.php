<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: ../index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard - OEMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container glass animate-fade">
        <h2>Welcome, <?php echo $_SESSION['full_name']; ?> <span style="font-weight: normal;">(Student)</span></h2>
        <ul class="dashboard-links">
            <li><a href="../exam.php">📝 Take Exam</a></li>
            <li><a href="../result.php">📊 View Results</a></li>
            <li><a href="../home.php">🚪 Logout</a></li>
        </ul>
    </div>
</body>
</html>
