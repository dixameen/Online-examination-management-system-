<?php
session_start();
include 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: index.php");
    exit();
}

// Select exam
if (!isset($_GET['exam_id'])) {
    $exams = $conn->query("SELECT * FROM exams");
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Select Exam</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
    <div class="container glass animate-fade">
        <h2>Select an Exam</h2><ul class="dashboard-links">';
    while ($row = $exams->fetch_assoc()) {
        echo "<li><a href='exam.php?exam_id=" . $row['id'] . "'>" . $row['title'] . " (" . $row['duration'] . " mins)</a></li>";
    }
    echo "</ul><p><a href='student/dashboard.php' class='btn-link'>🔙 Back</a></p></div></body></html>";
    exit();
}

$exam_id = $_GET['exam_id'];
$msg = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $score = 0;
    $total = count($_POST['answers']);

    foreach ($_POST['answers'] as $question_id => $student_answer) {
        $q = $conn->query("SELECT correct_option FROM questions WHERE id = $question_id")->fetch_assoc();
        if (strtoupper($student_answer) == strtoupper($q['correct_option'])) {
            $score++;
        }
    }

    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("INSERT INTO results (user_id, exam_id, score) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $user_id, $exam_id, $score);
    $stmt->execute();

    $msg = "✅ Exam submitted! Your score: $score out of $total";
}

// Fetch questions
$questions = $conn->query("SELECT * FROM questions WHERE exam_id = $exam_id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Take Exam</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container glass animate-slide">
        <h2>Exam Questions</h2>

        <?php if ($msg): ?>
            <div class="message success"><?php echo $msg; ?></div>
        <?php endif; ?>

        <form method="post">
            <?php while ($row = $questions->fetch_assoc()): ?>
                <div class="question-block">
                    <p><strong><?php echo $row['question_text']; ?></strong></p>
                    <label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="A" required> <?php echo $row['option_a']; ?></label><br>
                    <label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="B"> <?php echo $row['option_b']; ?></label><br>
                    <label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="C"> <?php echo $row['option_c']; ?></label><br>
                    <label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="D"> <?php echo $row['option_d']; ?></label><br><br>
                </div>
            <?php endwhile; ?>

            <input type="submit" value="Submit Exam">
        </form>

        <p><a href="student/dashboard.php" class="btn-link">🔙 Back to Dashboard</a></p>
    </div>
</body>
</html>
