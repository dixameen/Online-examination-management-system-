CREATE DATABASE  IF NOT EXISTS `oems` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `oems`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: oems
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `duration` int NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (3,'SEN3311',10,5,'2025-06-17 13:26:19'),(7,'GSP3211',40,5,'2025-06-19 00:36:19'),(8,'eee',1,10,'2025-06-19 02:04:08');
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exam_id` int DEFAULT NULL,
  `question_text` text NOT NULL,
  `option_a` varchar(255) DEFAULT NULL,
  `option_b` varchar(255) DEFAULT NULL,
  `option_c` varchar(255) DEFAULT NULL,
  `option_d` varchar(255) DEFAULT NULL,
  `correct_option` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_id` (`exam_id`),
  CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (2,3,'Which of the following is NOT a type of software testing?\r\n',' Unit Testing','Integration Testing','Deployment Testing',' Mutation Testing','c'),(3,3,'What is the main goal of software quality assurance (SQA)?','To reduce the number of programmers',' To increase the price of the software','To ensure the software meets specified requirements and is free of defects','To deliver the software quickly','c'),(4,3,'Which testing is performed without executing the code?','Functional Testing','Static Testing','Regression Testing',' System Testing','B'),(8,7,'1. What does the Arabic term Khitbah refer to?\r\n','A) The marriage contract','B) The process of betrothal','C) The divorce procedure','D) The Walimah ceremony','B'),(9,7,'2. The term Khitbah is mentioned in the Qur\'an in which Surah?\r\n','A) Al-Baqarah 2:235 ','B) Al-Nisa 4:3','C) Aal-Imran 3:14','D) Al-Rum 30:21','A'),(10,7,'3. According to Jabir bn Abdullahi (R.A), why should a suitor see a woman before proposing?\r\n\r\n','A) To confirm her family status','B) To bring love between them','C) To negotiate dowry','D) To test her faith','B'),(11,7,'4. The period of Khitbah serves as:\r\n','A) A time for wedding planning','B) An opportunity to examine religious and moral uprightness ','C) Time to prepare dowry payment','D) None of the above','B'),(12,7,'5. Who should preferably be present when a suitor meets the woman during Khitbah?\r\n','A) The Imam','B) Mahram (Relative within prohibited degree of marriage) ','C) Her friends','D) The Judge (Qadi)','B');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `exam_id` int DEFAULT NULL,
  `score` int DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `results_ibfk_2` (`exam_id`),
  CONSTRAINT `results_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `results_ibfk_2` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `results`
--

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` VALUES (5,3,3,1,'2025-06-17 14:11:18'),(6,3,3,2,'2025-06-17 16:30:51'),(7,3,3,1,'2025-06-17 16:33:10'),(8,3,3,2,'2025-06-17 16:34:17'),(9,8,3,1,'2025-06-17 16:58:33'),(10,8,3,2,'2025-06-17 17:01:20'),(11,3,3,2,'2025-06-19 00:33:58'),(12,3,7,5,'2025-06-19 00:46:39'),(13,9,7,5,'2025-06-19 02:00:34');
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Nurddeensanimagaji','nuraddeesanimagaji@gmail.com','$2y$10$/OfX1jPrSV7zsDZ.rMi5i.ENzDFClv05XsUzbosCR9U.JHuR66CUK','student','2025-06-16 11:59:12'),(2,'Nurddeensanimagaji','nuraddeesanimagaji19@gmail.com','$2y$10$3zMNUEZIn1PAj4REYS8CmOlipSFBiALxRkgpGOY8IqfMxgMk2lgMK','admin','2025-06-16 12:08:24'),(3,'Nurddeensanimagaji','user@example.com','$2y$10$xuDlRvj6WofFJt5mui8al.v7lR/.H1lhPD8fWZ857FFaUESBiji1S','student','2025-06-16 20:45:16'),(4,'Nurddeensanimagaji','EE@fff.com','$2y$10$rFjBBI1Ibu9k9/sRgzmrC.88VHrHHigY5a5w6T0rE6ZRpH6Igy0k2','admin','2025-06-17 13:21:01'),(5,'Nurddeensanimagaji','kangire@gmail.com','$2y$10$g7KDRxdMSfO45xIEGK6ng.Ld3zM/YHdQKJRc7UsDkNAdeJJtKlzgu','admin','2025-06-17 13:25:28'),(6,'admin','usuyudi@gmail.com','$2y$10$u6svw2Ptcb9R2NoEonOTKe0U4a0.3HgkhNOwhGUozPNUHYrqYl67u','student','2025-06-17 16:35:39'),(7,'admin','aishaabubakar@gmail.com','$2y$10$t27ujYD2LRw6MyVhzhuJl.3TMe/if9iAZT60wNXv/QNQol3rxiwJW','admin','2025-06-17 16:43:12'),(8,'ZIMIT','syzimit@gmail.com','$2y$10$EJTqnWOlHtAheuFEfuyGq.VlF4JaZF2PT23BlzKrsv8hV6K7ufeDm','student','2025-06-17 16:57:35'),(9,'Username','user1@example.com','$2y$10$dxP8/bvFDuh8AVWp7IDqCeRSrGMVLj7sZmyYFE8It2ZTFNa4gNqze','student','2025-06-19 01:56:27'),(10,'admin','EE@ffff.com','$2y$10$Glq4r9cvt7RSLBetxrftk.8sL3zStZSl7wkA0/s0wGS/fPbgEz7ea','admin','2025-06-19 01:56:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'oems'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-20  8:22:59
