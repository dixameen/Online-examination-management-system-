<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit();
}

$exam_id = $_GET['exam_id'] ?? null;
$msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $question = $_POST['question'];
    $a = $_POST['option_a'];
    $b = $_POST['option_b'];
    $c = $_POST['option_c'];
    $d = $_POST['option_d'];
    $correct = strtoupper($_POST['correct_option']);

    $stmt = $conn->prepare("INSERT INTO questions (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $exam_id, $question, $a, $b, $c, $d, $correct);

    if ($stmt->execute()) {
        $msg = "<div class='message success'>Question added successfully!</div>";
    } else {
        $msg = "<div class='message error'>Error: " . $stmt->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Questions</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container slide-in">
        <h2>Add Question to Exam #<?php echo $exam_id; ?></h2>

        <?php echo $msg; ?>

        <form method="post">
            <label>Question:</label>
            <textarea name="question" rows="3" required></textarea>

            <label>Option A:</label>
            <input type="text" name="option_a" required>

            <label>Option B:</label>
            <input type="text" name="option_b" required>

            <label>Option C:</label>
            <input type="text" name="option_c" required>

            <label>Option D:</label>
            <input type="text" name="option_d" required>

            <label>Correct Option (A/B/C/D):</label>
            <input type="text" name="correct_option" maxlength="1" required>

            <input type="submit" value="Add Question">
        </form>

        <p style="text-align:center; margin-top: 20px;"><a href="dashboard.php">⬅ Back to Dashboard</a></p>
    </div>
</body>
</html>
