<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit();
}

$msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $duration = $_POST['duration'];
    $created_by = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO exams (title, duration, created_by) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $title, $duration, $created_by);

    if ($stmt->execute()) {
        $msg = "Exam created successfully. <a href='add_questions.php?exam_id=" . $stmt->insert_id . "'>Add Questions</a>";
    } else {
        $msg = "Error creating exam: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Exam</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <h2>Create New Exam</h2>

        <?php if ($msg): ?>
            <div class="message success"><?php echo $msg; ?></div>
        <?php endif; ?>

        <form method="post">
            <label>Exam Title:</label>
            <input type="text" name="title" required>

            <label>Duration (minutes):</label>
            <input type="number" name="duration" required>

            <input type="submit" value="Create Exam">
        </form>

        <p><a href="dashboard.php">⬅️ Back to Dashboard</a></p>
    </div>
</body>
</html>
