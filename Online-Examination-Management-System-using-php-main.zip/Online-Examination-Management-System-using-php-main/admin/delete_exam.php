<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $exam_id = $_GET['id'];

    // Delete from results first
    $stmt1 = $conn->prepare("DELETE FROM results WHERE exam_id = ?");
    $stmt1->bind_param("i", $exam_id);
    $stmt1->execute();

    // Delete from questions next
    $stmt2 = $conn->prepare("DELETE FROM questions WHERE exam_id = ?");
    $stmt2->bind_param("i", $exam_id);
    $stmt2->execute();

    // Finally delete the exam
    $stmt3 = $conn->prepare("DELETE FROM exams WHERE id = ?");
    $stmt3->bind_param("i", $exam_id);
    if ($stmt3->execute()) {
        header("Location: manage_exams.php?msg=deleted");
        exit();
    } else {
        echo "Error deleting exam: " . $stmt3->error;
    }
} else {
    echo "Invalid exam ID.";
}
?>
