<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid exam ID.";
    exit();
}

$exam_id = $_GET['id'];
$msg = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST['title']);
    $duration = intval($_POST['duration']);

    $stmt = $conn->prepare("UPDATE exams SET title = ?, duration = ? WHERE id = ?");
    $stmt->bind_param("sii", $title, $duration, $exam_id);

    if ($stmt->execute()) {
        header("Location: manage_exams.php?msg=updated");
        exit();
    } else {
        $msg = "Error updating exam: " . $stmt->error;
    }
}

// Fetch exam info
$stmt = $conn->prepare("SELECT title, duration FROM exams WHERE id = ?");
$stmt->bind_param("i", $exam_id);
$stmt->execute();
$stmt->bind_result($title, $duration);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Exam - OEMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="container">
    <h2>Edit Exam</h2>

    <?php if ($msg): ?>
        <div class="message error"><?php echo $msg; ?></div>
    <?php endif; ?>

    <form method="post">
        <label>Exam Title</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($title); ?>" required>

        <label>Duration (in minutes)</label>
        <input type="number" name="duration" value="<?php echo htmlspecialchars($duration); ?>" required>

        <input type="submit" value="Update Exam">
    </form>

    <ul>
        <li><a href="manage_exams.php">Back to Manage Exams</a></li>
    </ul>
</div>

</body>
</html>
