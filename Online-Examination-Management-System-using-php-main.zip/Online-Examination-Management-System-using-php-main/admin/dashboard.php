<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - OEMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome, <?php echo $_SESSION['full_name']; ?> (Admin)</h2>
        
        <ul class="dashboard-links">
            <li><a href="create_exam.php">📝 Create New Exam</a></li>
            <li><a href="manage_exams.php">🗂️ Manage Exams</a></li>
            <li><a href="../home.php">🚪 Logout</a></li>
        </ul>
    </div>
</body>
</html>
