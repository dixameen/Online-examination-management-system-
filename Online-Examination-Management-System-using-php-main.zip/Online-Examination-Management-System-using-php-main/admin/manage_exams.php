<?php
session_start();
include '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$result = $conn->query("SELECT * FROM exams ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Exams - OEMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background: linear-gradient(to right, #f9f9f9, #e6f0ff);
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 30px;
        }

        .container {
            background: #fff;
            max-width: 960px;
            margin: auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #003366;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #003366;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .action-link {
            text-decoration: none;
            padding: 6px 10px;
            margin: 0 3px;
            color: #fff;
            background: #007acc;
            border-radius: 5px;
            transition: 0.3s ease;
        }

        .action-link:hover {
            background-color: #005fa3;
        }

        .delete {
            background-color: #e74c3c;
        }

        .delete:hover {
            background-color: #c0392b;
        }

        ul {
            margin-top: 20px;
            padding-left: 0;
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        ul li {
            list-style: none;
        }

        ul li a {
            text-decoration: none;
            padding: 10px 20px;
            background: #003366;
            color: white;
            border-radius: 6px;
            transition: 0.3s ease;
        }

        ul li a:hover {
            background-color: #005fa3;
        }

        .message {
            text-align: center;
            padding: 12px;
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 6px;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Exams</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Duration</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($exam = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($exam['title']); ?></td>
                    <td><?php echo $exam['duration']; ?> min</td>
                    <td><?php echo $exam['created_at']; ?></td>
                    <td>
                        <a class="action-link" href="add_questions.php?exam_id=<?php echo $exam['id']; ?>">Add Questions</a>
                        <a class="action-link" href="edit_exam.php?id=<?php echo $exam['id']; ?>">Edit</a>
                        <a class="action-link delete" href="delete_exam.php?id=<?php echo $exam['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="message">No exams found.</p>
    <?php endif; ?>

    <ul>
        <li><a href="create_exam.php">Create New Exam</a></li>
        <li><a href="dashboard.php">Back to Dashboard</a></li>
    </ul>
</div>

</body>
</html>
