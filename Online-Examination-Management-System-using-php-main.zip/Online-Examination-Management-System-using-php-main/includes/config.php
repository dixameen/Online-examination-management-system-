<?php
// Database configuration
$localhost = 'localhost';
$username = 'root';          // Default XAMPP username
$password = '@Kangire1084';              
$dbname = 'oems';

// Create connection
$conn = new mysqli($localhost, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
