<?php
include 'includes/config.php';
echo "Database connected successfully!";
?>
